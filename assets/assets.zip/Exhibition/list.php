<?php
function getImages($dir) {
    $allowed = ['jpg','jpeg','png','gif','webp'];
    $images = [];
    foreach (scandir($dir) as $file) {
        if ($file === '.' || $file === '..') continue;
        $path = $dir . DIRECTORY_SEPARATOR . $file;
        if (is_file($path)) {
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (in_array($ext, $allowed)) {
                $images[] = $file;
            }
        }
    }
    return $images;
}

function findCover($images) {
    foreach ($images as $img) {
        if (stripos($img, 'cover') === 0) { // عکس‌هایی که اسمشون با cover شروع میشه
            return $img;
        }
    }
    return count($images) ? $images[0] : null; // اگر نبود، اولین عکس
}

$base = __DIR__;
$result = [];
foreach (scandir($base) as $folder) {
    if ($folder === '.' || $folder === '..') continue;
    if (is_dir("$base/$folder")) {
        $images = getImages("$base/$folder");
        $result[] = [
            'title'   => $folder,                         // اسم پوشه (عنوان کامل)
            'cover'   => findCover($images),              // کاور: cover.* یا اولین عکس
            'images'  => $images                          // لیست عکس‌ها
        ];
    }
}

header('Content-Type: application/json; charset=utf-8');
echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
?>
